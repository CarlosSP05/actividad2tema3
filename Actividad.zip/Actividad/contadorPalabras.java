package Actividad;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;


public class contadorPalabras {
    public static void main(String[] args) {
        String nombreArchivo = "entrada.txt";
        int totalPalabras = 0;

        try (BufferedReader br = new BufferedReader(new FileReader(nombreArchivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                if (!linea.trim().isEmpty()) {
                    String[] palabras = linea.trim().split("\\s+");
                    totalPalabras += palabras.length;
                }
            }
            System.out.println("Número total de palabras: " + totalPalabras);
        } catch (IOException e) {
            System.err.println("Error al abrir o leer el archivo " + nombreArchivo);
        }
    }
}


